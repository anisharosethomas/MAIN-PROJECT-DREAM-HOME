import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
public BookDetails:any=[{title:"Wings of Fire",author:"APJ Abdul Kalam",publisher:"DC Books"},{title:"Book2",author:"Author2",publisher:"Publisher2"},{title:"Book3",author:"Author3",publisher:"Publisher3"}];
selbook:any;
addBook(data:any){
  this.selbook=data;  
}
constructor() { }

  ngOnInit() {
  }

}
