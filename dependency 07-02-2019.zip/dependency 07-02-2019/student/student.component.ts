import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
 @Input() rollno:number;
@Input() sname:string;
@Input() batch:string;
@Input() dept:string;
@Output() sendStudent:EventEmitter<any>=new EventEmitter();
selectstudent(){
  let selectstudent:any={srollno:this.rollno,
    stname:this.sname,
    sbatch:this.batch,
    sdept:this.dept};
    this.sendStudent.emit(selectstudent);

}
  constructor() { }

  ngOnInit() {
  }

}
