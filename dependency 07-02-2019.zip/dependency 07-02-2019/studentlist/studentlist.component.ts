import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
public StudentDetails:any=[{rollno:"1",sname:"Jins",batch:"MCALE",dept:"MCA"},{rollno:"2",sname:"Aparna",batch:"MCALE",dept:"MCA"},{rollno:"3",sname:"Anisha",batch:"MCALE",dept:"MCA"}];
  selstudent:any;

  addstudent(data:any)
  {
    this.selstudent=data;
  }
constructor() { }

  ngOnInit() {
  }

}
