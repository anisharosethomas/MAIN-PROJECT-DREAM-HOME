<form method="post" action="{{route('student.update',$student->id)}}" >
@method('PATCH')
  @csrf
  <title></title>
    Roll No
    <input type="text" name="title" value={{$student->rollno}}/>
    <br>
    Name
    <input type="text" name="body" value={{$student->name}}/>
    <br>
    College
    <input type="text" name="body" value={{$student->college}}/>
    <br>
    <button type="submit" name="Sub">Update</button>
    <br>
</form>
