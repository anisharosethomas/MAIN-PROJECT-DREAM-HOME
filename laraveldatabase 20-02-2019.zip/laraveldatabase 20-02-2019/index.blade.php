<table border="1">
  <thead>
  <tr>
    <th><b>Roll No</td>
    <td><b>Name</td>
    <td><b>Collage</td>
  </tr>
</thead>
<tbody>
  @foreach($studentdetails as $student)
  <tr>
    <td>{{$student->rollno}}</td>
   <td>{{$student->name}}</td>
  <td>{{$student->college}}</td>
  <td><a href="{{route('student.edit',$student->id)}}">Edit</a>
    <td> <form action="{{route('student.destroy',$student->id)}}" method="post">
    @csrf
    @method('DELETE')
    <button type="submit">Delete</button>
  </form>
  </td>
</tr>
@endforeach
</tbody>
</table>
