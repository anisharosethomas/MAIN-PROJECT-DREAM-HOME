<form method="post" action="{{route('student.store')}}" >
  @csrf
  <title></title>
    Roll no
    <input type="text" name="rollno"/>
    <br>
    Name
    <input type="text" name="name"/>
    <br>
    Collage
    <input type="text" name="college"/>
    <br>
    <button type="submit" name="Sub">Add</button>
    <br>
</form>
