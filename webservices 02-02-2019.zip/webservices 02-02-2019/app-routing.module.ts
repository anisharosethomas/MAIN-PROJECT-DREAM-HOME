import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import{ LoginComponent } from './login/login.component';

import { HomeComponent } from './home/home.component';
import { ApplyComponent } from './apply/apply.component';

const routes: Routes = [{path:"",component:HomeComponent},
{path:"Home",component:HomeComponent},
{path:"Apply",component:ApplyComponent},
{path:"Login",component:LoginComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
