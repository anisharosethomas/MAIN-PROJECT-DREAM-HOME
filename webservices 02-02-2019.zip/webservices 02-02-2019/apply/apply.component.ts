import { Component, OnInit } from '@angular/core';
import {} from '../builder';
import {NgForm} from '@angular/forms';
import { ServiceService } from '../service.service';
@Component({
  selector: 'app-apply',
  templateUrl: './apply.component.html',
  styleUrls: ['./apply.component.css']
})
export class ApplyComponent implements OnInit {
   builder= this.builder;
   error='';
   sucess='';
   isRegistered='';
  constructor(private applyService:ServiceService) 
  { 
    
  }
ngOnInit() {
  } 

registration(f: NgForm){
  this.error='';
  this.sucess='';
  this.applyService.store(this.builder).subscribe(data=>{
  this.isRegistered="true";
  console.log("Registered Sucessfully");
  f.reset();
},
(err) => {this.error= err;
  this.isRegistered="false";
}
);
}
}
   
