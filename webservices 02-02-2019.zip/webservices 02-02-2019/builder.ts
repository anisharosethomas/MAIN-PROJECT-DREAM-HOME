export class builder {
    name:String;
    uname:String;
    pass:String;
    id?:number;
    constructor(id:number,name:String,uname:String,pass:String){
        
    }
}