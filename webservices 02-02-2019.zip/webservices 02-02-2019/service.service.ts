import { Injectable } from '@angular/core';
import {HttpClient,HttpErrorResponse} from '@angular/common/http';
import {builder} from './builder';
import { Observable, throwError } from 'rxjs';
import { post } from 'selenium-webdriver/http';
import {map,catchError} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
builder:builder[];
  constructor(private http:HttpClient) { }
  store(builder:builder):Observable<builder[]> {
      return this.http.post(`http://localhost/reg.php`,{data:builder}).pipe
      (map((res)=>{
        this.builder=(res['data']);
        return this.builder;
      }),
     catchError(this.handleError));
  }


  private handleError(error:HttpErrorResponse)
  {
   console.log(error);
   return throwError("Error!Return through");
  }
}
